module.exports = {
   // credentials to the DB are here. HIDDEN and not exposed outside
   // NOTE: YOU SHOULD REPLACE WITH YOUR OWN NATURALLY. These are the ones
   // that you set up 
   config : {
    "host"     : "seats4udb.c38ykcydfvfr.us-east-1.rds.amazonaws.com",
    "user"     : "seats4uAdmin", 
    "password" : "SoftEng77777",
    "database" : "seats4u"
  }
}
